exports.data = function () {
    return new Date();
};