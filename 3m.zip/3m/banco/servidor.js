var http = require('http');
var formidable = require('formidable');
var fs = require('fs');
var mysql = require('mysql');
var bcrypt = require("bcrypt");
var saltRounds = 10;
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "node"
});
con.connect(function (err) {
    console.log("Conectado!");
});
http.createServer(function (req, res) {
    res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf - 8'});
    if(req.url == '/cadastro') {
        fs.readFile('form-cadastro.html', function (err, data) {
            res.write(data);
            return res.end();
        });
    }else if (req.url == '/login') {
        fs.readFile('form-login.html', function (err, data) {
            res.write(data);
            return res.end();
        })
    } else if (req.url == '/insere-dados') {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            console.log(fields.senha[0])
            bcrypt.hash(fields.senha[0], saltRounds, function (err, hash) {
                if (err) throw err;
                var sql = "INSERT INTO usuario (nome, email, senha) VALUES ?";
                var values = [[fields.nome, fields.email, hash]];
                con.query(sql, [values], function (err, result) {
                    if (err) throw err;
                    console.log("Numero de registros inseridos: " + result.affectedRows);
                });
            });
            res.write("Dados inseridos no Banco com Sucesso");
            res.end();
        });
    } else if (req.url == '/verifica-login') {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err1, fields, files) {
            if (err1) throw err1
            var senha = fields.senha[0];
            var sql = "SELECT * FROM usuario where email = '" + fields.email + "'";
            con.query(sql, function (err, result) {
                if (err) throw err;
                if (result.length) {
                    bcrypt.compare(senha, result[0]['senha'], function (err, resultado) {
                        if (err) throw err;
                        if (resultado) {
                            res.write("Login realizado com sucesso");
                            res.end();
                        }
                        else {
                            res.write("A senha é diferente da que está no banco");
                            res.end();
                        }
                    });
                }
            });
        });
    }
}).listen(3000);   