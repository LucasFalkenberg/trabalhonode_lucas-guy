var mysql = require('mysql');
var con = mysql.createConnection({
 host: "localhost",
 user: "root",
 password: "",
 database: "node"
});

con.connect(function(err) {
    if (err) throw err;
    var sql ="SELECT * FROM usuario"
    con.query(sql, function (err, result, fields) {
    if (err) throw err;
    console.log(result[0].nome);
    });
    con.end();
   });